let config = { 
	"accessKeyId": "AKIAJ7JAIO5P4BJQOZNA",
	"secretAccessKey": "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",
	"region": "us-east-1",
	"STRIPE_SECRET_KEY" : "sk_test_TwygZhO8cfmbvCdRzpjacgq9"
}
	
module.exports = config;
